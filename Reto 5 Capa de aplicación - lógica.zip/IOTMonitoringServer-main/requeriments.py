from os import lseek
